Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },
  data: {
    inputValue: ''
  },
  properties: {
    placeholderText: {
      type: String,
      value: '搜索商品名称或商品编码'
    }
  },
  methods: {
    // 公有方法
    getSearchInput(e) {
      this.setData({
        inputValue: e.detail.value
      })
    },
    clearInput() {
      this.setData({
        inputValue: ''
      })
    },
    // 内部私有方法
    _search() {
      this.triggerEvent("searchEvent")
    },
    //清空搜索框
    clearInput() {
      this.setData({
        inputValue: ""
      })
    }
  }
})