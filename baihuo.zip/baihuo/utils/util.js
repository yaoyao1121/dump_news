const app = getApp()
const sha1 = require("./sha1.js")

const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('-')
}

const prevDay = (today, addDayCount) =>{
  var dd;
  if (today) {
    dd = new Date(today);
  } else {
    dd = new Date();
  }
  dd.setDate(dd.getDate() - addDayCount);//获取AddDayCount天后的日期 
  var year = dd.getFullYear();
  var month = dd.getMonth() + 1;//获取当前月份的日期 
  var day = dd.getDate();
  if (month < 10) {
    month = '0' + month;
  };
  if (day < 10) {
    day = '0' + day;
  };
  return [year, month, day].map(formatNumber).join('-')
}
const nextDay = (today, addDayCount) => {
  var dd;
  if (today) {
    dd = new Date(today);
  } else {
    dd = new Date();
  }
  dd.setDate(dd.getDate() + addDayCount);//获取AddDayCount天后的日期 
  var year = dd.getFullYear();
  var month = dd.getMonth() + 1;//获取当前月份的日期 
  var day = dd.getDate();
  if (month < 10) {
    month = '0' + month;
  };
  if (day < 10) {
    day = '0' + day;
  };
  return [year, month, day].map(formatNumber).join('-')
}
const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

// API签名加密算法
// obj为要传递的数据，以对象形式,返回加密字符串
function sign(obj) {
  var key = Object.keys(obj).sort();
  // 排序后的新字符串
  var newStr = {}
  for (var i = 0; i < key.length; i++) {
    newStr[key[i]] = obj[key[i]]
  }
  var secret_str = sha1.sha1(JSON.stringify(newStr))
  return secret_str
}

function share(){
  return {
    title: app.globalData.transformTitle,
    path: app.globalData.transformUrl,
    imageUrl: app.globalData.transformImg
  }
}

module.exports = {
  formatTime: formatTime,
  sign: sign,
  prevDay: prevDay, 
  nextDay: nextDay,
  share: share
}


