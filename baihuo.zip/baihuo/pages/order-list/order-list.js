//获取应用实例
const app = getApp()
const Sign = require("../../utils/util.js")

Page({
  data: {
    //日期
    selectTime: Sign.prevDay(new Date(),1),
    today: Sign.prevDay(new Date(),1),
    optional: "../../images/zuolv.png",
    noOptional: "../../images/youhui.png",
    orderType:1,
    pageNum:1,
    list:[],
    //true连接 false不连接
    switchFlag:true,
    searchValue:""
  },
  onReady: function () {
    // 获得dialog组件
    this.search = this.selectComponent("#search")
  },
  onLoad(options){
    var selectTime = options.vtime;
    if (selectTime != this.data.today){
      this.setData({
        noOptional: "../../images/youlv.png",
        selectTime: selectTime
      })
    }else{
      this.setData({
        noOptional: "../../images/youhui.png",
        selectTime: selectTime
      })
    }
  },
  onShow () {
    var pageNum = this.data.pageNum;
    var status = this.data.orderType;
    this.getList(pageNum,status)
  },
  //获取列表
  getList (pageNum,status) {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var time = this.data.selectTime;
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, account: loginInfo.account, identity: loginInfo.identity, time: time, type: status, page: pageNum, timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-orders/list',
      method: "POST",
      data: {
        shop_id: loginInfo.shop_id, 
        account: loginInfo.account, 
        identity: loginInfo.identity, 
        time: time, 
        type: status, 
        page: pageNum,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        if (res.data.code == 0) {
          var oldlist = _this.data.list;
          if (_this.data.switchFlag){//连接
            _this.setData({
              list: oldlist.concat(res.data.res.orders_list)
            })
          }else{//不连接
            _this.setData({
              list: res.data.res.orders_list
            })
          }
          var aimlist = _this.data.list;
          if(aimlist.length == 0){
            wx.showToast({
              title: "暂无数据",
              icon: 'none',
              duration: 3000
            })
          }
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  },
  //触底
  onScrollBottom () {
    var page = this.data.pageNum;
    this.setData({
      pageNum: page + 1,
      switchFlag: true
    })
    if(this.data.searchValue == ""){
      var status = this.data.orderType;
      this.getList(this.data.pageNum,status);
    }else{
      this.getSearchList();
    }
  },
  //切换订单状态
  tab (e) {
    var orderType = e.currentTarget.dataset.order;
    this.setData({
      orderType: orderType,
      pageNum:1,
      switchFlag:false,
      searchValue:""
    })
    this.search.clearInput();
    
    var pageNum = this.data.pageNum;
    var status = this.data.orderType;
    this.getList(pageNum, status)
  },
  //切换已支付订单状态
  paytab (e) {
    var orderType = e.currentTarget.dataset.order;
    this.setData({
      orderType: orderType,
      pageNum: 1,
      switchFlag:false
    })
    var pageNum = this.data.pageNum;
    var status = this.data.orderType;
    this.getList(pageNum, status)
  },
  //进入订单详情
  toDetail (e) {
    if (e.currentTarget.dataset.ordertype == 1 || e.currentTarget.dataset.ordertype == 2){
      wx.setStorageSync("order_id", e.currentTarget.dataset.orderid)
      wx.navigateTo({
        url: '/pages/order-detail/order-detail'
      })
    }
  },
  //搜索
  _search () {
    this.setData({
      pageNum:1,
      switchFlag:false,
      searchValue: this.search.data.inputValue
    })
    this.getSearchList();
  },
  getSearchList () {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var pageNum = _this.data.pageNum;
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, account: loginInfo.account, identity: loginInfo.identity, page: pageNum, order_id: _this.search.data.inputValue, timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-orders/dlist',
      method: 'POST',
      data: {
        shop_id: loginInfo.shop_id,
        account: loginInfo.account,
        identity: loginInfo.identity,
        page: pageNum,
        order_id: _this.search.data.inputValue,
        timestamp: timestamp,
        sign: str
      },
      success(res) {
        if (res.data.code == 0) {
          if (_this.data.switchFlag) {
            var oldlist = _this.data.list;
            _this.setData({
              list: oldlist.concat(res.data.res.orders_list),
              orderType:1
            })
          } else {
            _this.setData({
              list: res.data.res.orders_list,
              orderType: 1
            })
          }
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  },
  //日期选择
  startTimeChange (e) {
    var _this = this;
    _this.setData({
      selectTime: e.detail.value,
      pageNum: 1,
      switchFlag:false
    })
    let date = new Date(e.detail.value)
    let gameOver = new Date();
    if (gameOver.toLocaleDateString() == date.toLocaleDateString()) {
      this.setData({
        noOptional: "../../images/youhui.png"
      })
    } else {
      this.setData({
        noOptional: "../../images/youlv.png",
        optional: "../../images/zuolv.png"
      })
    }
    this.getList(_this.data.pageNum, _this.data.orderType)
  },
  //前一天
  prev() {
    var _this = this;
    let date = new Date(this.data.selectTime)
    let prevDay = Sign.prevDay(date, 1);
    this.setData({
      selectTime: prevDay,
      optional: "../../images/zuolv.png",
      noOptional: "../../images/youlv.png",
      pageNum: 1,
      switchFlag: false
    })
    this.getList(_this.data.pageNum, _this.data.orderType)
  },
  //后一天
  next() {
    var _this = this;
    let date = new Date(this.data.selectTime)
    let gameOver = new Date();
    let nextDay = Sign.nextDay(date, 1);
    if (gameOver < new Date(nextDay)) {
      this.setData({
        noOptional: "../../images/youhui.png"
      })
    } else {
      this.setData({
        selectTime: nextDay,
        noOptional: "../../images/youlv.png",
        optional: "../../images/zuolv.png",
        pageNum: 1,
        switchFlag: false
      })
      this.getList(_this.data.pageNum, _this.data.orderType)
    }
  }
})