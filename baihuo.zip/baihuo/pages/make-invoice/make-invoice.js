const app = getApp()
const Sign = require("../../utils/util.js")
Page({
  data: {
    //角色 账号
    user: "",
    account: "",
    userInfo: {},
    //列表
    list:[],
    //单品优惠基础上再优惠的数据
    zhekou:0,
    //应付的钱
    real_pay:"",
    //勾选件数
    listlength:0,
    //全选
    allCheck:true
  },
  onShow () {
    //角色 账号
    var loginInfo = wx.getStorageSync("loginInfo");
    var user = "";
    if (loginInfo.identity == 0) {
      user = "店长";
    } else {
      user = "导购员";
    }
    this.setData({
      user: user,
      account: wx.getStorageSync("account"),
      userInfo: wx.getStorageSync("loginInfo")
    })
    //列表
    if(wx.getStorageSync("checklist")){
      var list = wx.getStorageSync("checklist");
      this.setData({
        list: wx.getStorageSync("checklist"),
        listlenth: list.length
      })
      this.getOrigin()
    }
  },
  //添加
  add () {
    wx.setStorageSync("checklist", this.data.list);
    wx.navigateTo({
      url: '/pages/switch-goods/switch-goods',
    })
  },
  //勾选
  check (e) {
    var idx = e.currentTarget.dataset.idx;
    var item = e.currentTarget.dataset.item;
    var aim = "list["+idx+"].flag";
    this.setData({
      [aim]: !item.flag
    })
    this.getNum();
  },
  //输入原价
  original_price (e) {
    console.log(e);
    var idx = e.currentTarget.dataset.idx;
    var item = e.currentTarget.dataset.item;
    var value = e.detail.value;
    var aim = "list[" + idx + "].original_price";
    var aimxiaoji = "list[" + idx + "].xiaoji";
    this.setData({
      [aim]: value,
      [aimxiaoji]: Number(value) * Number(item.nums) - Number(item.disc_price)
    });
    this.getOrigin();
  },
  //输入优惠
  disc_price (e) {
    console.log(e);
    var idx = e.currentTarget.dataset.idx;
    var item = e.currentTarget.dataset.item;
    var value = e.detail.value;
    var aim = "list[" + idx + "].disc_price";
    this.setData({
      [aim]: value
    });
    if (item.original_price != ""){
      var aimxiaoji = "list[" + idx + "].xiaoji";
      this.setData({
        [aimxiaoji]: Number(item.original_price) * Number(item.nums) - Number(value)
      });
    }
    this.getOrigin();
  },
  //输入单品优惠基础上再优惠
  zhekou (e) {
    console.log(e)
    var value = e.detail.value;
    this.setData({
      zhekou: value
    });
    this.getOrigin();
  },
  //数量加 
  addnum (e) {
    var idx = e.currentTarget.dataset.idx;
    var item = e.currentTarget.dataset.item;
    var aim = "list[" + idx + "].nums";
    this.setData({
      [aim]: Number(item.nums)+1
    });
    if (item.original_price != "") {
      var aimxiaoji = "list[" + idx + "].xiaoji";
      this.setData({
        [aimxiaoji]: Number(item.original_price) * (Number(item.nums) + 1) - Number(item.disc_price)
      });
    }
    this.getOrigin()
  },
  //数量减 
  shortnum(e) {
    console.log(e);
    var idx = e.currentTarget.dataset.idx;
    var item = e.currentTarget.dataset.item;
    var aim = "list[" + idx + "].nums";
    var num = Number(item.nums);
    if (num<=0){
      num = 0;
    }else{
      num = Number(item.nums)-1;
    }
    this.setData({
      [aim]: num
    });
    if (item.original_price != "") {
      var aimxiaoji = "list[" + idx + "].xiaoji";
      this.setData({
        [aimxiaoji]: Number(item.original_price) * (Number(num)) - Number(item.disc_price)
      });
    }
    this.getOrigin()
  },
  //计算应付
  getOrigin () {
    var list = this.data.list;
    var yuanjia = 0;
    var youhui = 0;
    for(var i in list){
      if (list[i].original_price != ""){
        yuanjia += Number(list[i].original_price) * Number(list[i].nums);
      }
      if (list[i].disc_price != ""){
        youhui += list[i].disc_price;
      }
    }
    this.setData({
      real_pay: (Number(yuanjia) - Number(youhui) - Number(this.data.zhekou)).toFixed(2)
    })
  },
  //计算件数
  getNum(){
    var list = this.data.list;
    var num = 0;
    for(var i in list){
      if(list[i].flag){
        num++;
      }
    }
    this.setData({
      listlenth:num
    })
  },
  //全选
  allcheck () {
    var _this = this;
    var allFlag = this.data.allCheck;
    this.setData({
      allCheck: !allFlag
    })
    var list = this.data.list;
    for(var i in list){
      var aim = "list[" + i + "].flag";
      _this.setData({
        [aim]: !list[i].flag
      })
    }
    this.setData({
      list:list
    })
    this.getNum();
  },
  //确认
  sure () {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var timestamp = new Date().getTime()
    var goods_list = _this.data.list;
    var checklist=[];
    for(var i in goods_list){
      if(goods_list[i].flag){
        checklist.push(goods_list[i])
      }
    }
    var param = { shop_id: loginInfo.shop_id, account: _this.data.account, identity: loginInfo.identity, zhekou_price: _this.data.zhekou, goods_list: checklist,timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-orders/open',
      method: "POST",
      data: {
        shop_id: loginInfo.shop_id,
        account: _this.data.account, 
        identity: loginInfo.identity, 
        zhekou_price: _this.data.zhekou, 
        goods_list: checklist,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        console.log(res);
        if (res.data.code == 0) {
          wx.setStorageSync("order_id", res.data.res.order_id)
          wx.navigateTo({
            url: '/pages/order-detail/order-detail',
          })
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  }
})