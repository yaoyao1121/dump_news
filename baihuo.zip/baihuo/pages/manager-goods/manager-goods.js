const app = getApp()
const Sign = require("../../utils/util.js")

Page({
  data: {
    //切换值
    tabData:"up",
    //上架分页
    upPageNum:1,
    //下架分页
    downPageNum: 1,
    //上架商品列表
    upList:[],
    //下架商品列表
    downList:[],
    //角色 账号
    user:"",
    account:"",
    userInfo: {}
  },
  onReady: function () {
    // 获得dialog组件
    this.search = this.selectComponent("#search")
  },
  onShow () {
    console.log("onshow")
    this.setData({
      upList:[],
      downList:[]
    })
    //获取商品上架列表
    var upPageNum = this.data.upPageNum;
    this.getList(0, upPageNum);
    //获取商品下架列表
    var downPageNum = this.data.downPageNum;
    this.getList(1, downPageNum);
    //角色 账号
    var loginInfo = wx.getStorageSync("loginInfo");
    var user = "";
    if (loginInfo.identity == 0){
      user = "店长";
    }else{
      user = "导购员";
    }
    this.setData({
      user:user,
      account: wx.getStorageSync("account"),
      userInfo: wx.getStorageSync("loginInfo")
    })
  },
  //获取上架商品列表 0上架 1下架
  getList(status,pageNum) {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, status: status, page: pageNum, timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-goods/list',
      method: "POST",
      data: {
        shop_id: loginInfo.shop_id, 
        status: status, 
        page: pageNum,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        if (res.data.code == 0) {
          if (status == 0){//上架
            var oldlist = _this.data.upList;
            _this.setData({
              upList: oldlist.concat(res.data.res.goods_list)
            })
          }else{//下架
            var oldlist = _this.data.downList;
            _this.setData({
              downList: oldlist.concat(res.data.res.goods_list)
            })
          }
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  },
  //上架触底
  upScroll (){
    var page = this.data.upPageNum+1;
    this.setData({
      upPageNum: page
    })
    this.getList(0, this.data.upPageNum)
  },
  //下架触底
  downScroll() {
    var page = this.data.downPageNum + 1;
    this.setData({
      downPageNum: page
    })
    this.getList(1, this.data.downPageNum)
  },
  //搜索
  _search: function () {
    console.log(this.search.data.inputValue)

    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var status = 0;
    if (_this.data.tabData == "up"){
      status = 0;
    }else{
      status = 1;
    }
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, status: status, sou: _this.search.data.inputValue, timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-goods/dlist',
      method: "POST",
      data: {
        shop_id: loginInfo.shop_id, 
        status: status, 
        sou: _this.search.data.inputValue,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        console.log(res)
        if (res.data.code == 0) {
          if(status == 0){//上架
            _this.setData({
              upList: res.data.res.goods_list
            })
          }else{
            _this.setData({
              downList: res.data.res.goods_list
            })
          }
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  },
  //切换上下架
  tab (e) {
    this.setData({
      tabData: e.currentTarget.dataset.type
    });
  }
})