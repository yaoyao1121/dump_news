const app = getApp()
const Sign = require("../../utils/util.js")

Page({
  data: {
    //商品编码
    goodsCode:"",
    //商品名称
    goodsName:"",
    //销售方式 0大类 1单品
    saleType:0,
    //售价
    salePrice:"",
    //备注
    mark:"",
    //上下架
    status:["上架","下架"],
    //上下架 下标
    index:0
  },
  onShow () {

  },
  //输入商品编码
  inputCode (e) {
    this.setData({
      goodsCode:e.detail.value
    })
  },
  //输入商品名称
  inputName(e) {
    this.setData({
      goodsName: e.detail.value
    })
  },
  //输入售价
  inputPrice (e) {
    this.setData({
      salePrice: e.detail.value
    })
  },
  //输入备注
  inputMark (e) {
    this.setData({
      mark: e.detail.value
    })
  },
  //销售方式选择
  tabType (e) {
    var tabType = e.currentTarget.dataset.type;
    this.setData({
      saleType: tabType
    })
  },
  //选择上下架
  bindPickerChange (e) {
    this.setData({
      index: Number(e.detail.value)
    })
  },
  //保存
  save () {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var shop_id = loginInfo.shop_id;
    var goods_code = _this.data.goodsCode;
    var goods_name = _this.data.goodsName;
    var goods_type = _this.data.saleType;
    var status = _this.data.index;
    var price = _this.data.salePrice;
    var remark = _this.data.mark;
    var account = loginInfo.account;

    var timestamp = new Date().getTime()
    var param = { shop_id: shop_id, goods_code: goods_code, goods_name: goods_name, goods_type: goods_type, status: status, price: price, remark: remark, account:account,timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-goods/add',
      method: "POST",
      data: {
        shop_id: shop_id, 
        goods_code: goods_code, 
        goods_name: goods_name, 
        goods_type: goods_type, 
        status: status, 
        price: price, 
        remark: remark,
        account: account,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        if (res.data.code == 0) {
          wx.navigateBack({
            delta:1
          })
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  }
})