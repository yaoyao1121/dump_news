const app = getApp()
const Sign = require("../../utils/util.js")

Page({
  data: {
    //用户信息
    userInfo:{}
  },
  onShow () {
    this.setData({
      userInfo:wx.getStorageSync("loginInfo")
    });
  },
  //退出登录
  exit_login () {
    wx.navigateTo({
      url: '/pages/login/login',
    })
  }
})
