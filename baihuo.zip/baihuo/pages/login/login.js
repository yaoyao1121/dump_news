const app = getApp()
const Sign = require("../../utils/util.js")

Page({
  data: {
    //账号
    account:"",
    //密码
    password:"",
    //密码可见/不可见
    passType:false,
    //可登陆/不可登陆状态
    loginFlag:false,
    //记住/不记住
    rememberFlag:true
  },
  onShow () {
    if (wx.getStorageSync("account") != "" && wx.getStorageSync("password") != ""){
      this.setData({
        account: wx.getStorageSync("account"),
        password: wx.getStorageSync("password"),
        loginFlag:true
      })
    }
  },
  //密码可见/不可见切换
  passType () {
    var passType = this.data.passType;
    this.setData({
      passType:!passType
    })
  },
  //记住我
  remenber () {
    var rememberFlag = this.data.rememberFlag;
    this.setData({
      rememberFlag: !rememberFlag
    })
  },
  //账号输入
  account(e) {
    this.setData({
      account: e.detail.value
    })
  },
  //密码输入
  password (e) {
    this.setData({
      password: e.detail.value
    })
    var account = this.data.account;
    var password = this.data.password;
    if (account != "" && password.length >= 6){
      this.setData({
        loginFlag:true
      })
    }else{
      this.setData({
        loginFlag: false
      })
    }
  },
  //登录
  toLogin () {
    var _this = this
    if (_this.data.loginFlag){
      var timestamp = new Date().getTime()
      var param = { account: _this.data.account, password: _this.data.password, identity:0,timestamp: timestamp }
      var str = Sign.sign(param)
      wx.request({
        url: app.globalData.request + '/outapi/store-staff/login',
        method: "POST",
        data: {
          account: _this.data.account, 
          password: _this.data.password, 
          identity: 0,
          timestamp: timestamp,
          sign: str
        },
        success: function (res) {
          if (res.data.code == 0){
            wx.setStorageSync("loginInfo", res.data.res);
            var rememberFlag = _this.data.rememberFlag;
            wx.setStorageSync("account", _this.data.account);
            if (rememberFlag) {
              wx.setStorageSync("password", _this.data.password);
            } else {
              wx.removeStorageSync("password");
            }
            wx.navigateTo({
              url: '/pages/index/index',
            })
          }else{
            wx.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 3000
            })
          }
        }
      })
    }    
  }
})