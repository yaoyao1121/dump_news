const app = getApp()
const Sign = require("../../utils/util.js")

Page({
  data: {
    //搜索状态
    seaPop:false,
    //商品列表
    list:[],
    pageNum:1,
    //0 上架
    status:0,
    searchFlag:true,
    //选中的列表
    checkList:[],
    //搜索内容
    search_value:"搜索商品名称"
  },
  onReady: function () {
    // 获得dialog组件
    this.search = this.selectComponent("#search")
  },
  onShow  () {
    this.getList(this.data.pageNum,this.data.status)
  },
  //列表
  getList(pageNum,status) {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, status: status, page: pageNum, timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-goods/list',
      method: "POST",
      data: {
        shop_id: loginInfo.shop_id,
        status: status,
        page: pageNum,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        console.log(res);
        if (res.data.code == 0) {
          var oldlist = _this.data.list;
          var resinfo = res.data.res.goods_list;
          for(var i in resinfo){
            resinfo[i].flag = false;
            if (resinfo[i].goods_type == 0){//大类
              resinfo[i].original_price = "";
            }else{//单品
              resinfo[i].original_price = resinfo[i].price;
            }
            resinfo[i].disc_price = 0;
            resinfo[i].nums = 1;
            resinfo[i].xiaoji = 0;
          }
          if (_this.data.searchFlag){//连接
            _this.setData({
              list: oldlist.concat(resinfo)
            })
          }else{//不连接
            _this.setData({
              list: resinfo
            })
          }
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  },
  //触底
  onBottomScroll () {
    var pageNum = this.data.pageNum;
    var status = this.data.status;
    this.setData({
      pageNum: pageNum + 1,
      searchFlag:true
    })
    this.getList(pageNum+1, status);
  },
  //选择商品
  check (e) {
    var item = e.currentTarget.dataset.item;
    var idx = e.currentTarget.dataset.idx;
    var aim = "list["+idx+"].flag";
    this.setData({
      [aim]: !item.flag
    })
  },
  //搜索状态
  searchShow () {
    this.setData({
      seaPop:true
    })
  },
  //搜索取消
  seaCancel () {
    this.setData({
      seaPop: false
    })
  },
  //搜索
  _search: function () {
    var _this = this;
    if (this.search.data.inputValue == ""){
      _this.setData({
        pageNum:1,
        seaPop:false,
        search_value: "搜索商品名称"
      })
      _this.getList(_this.data.pageNum, _this.data.status)
    }else{
      var loginInfo = wx.getStorageSync("loginInfo");
      var status = 0;
      if (_this.data.tabData == "up") {
        status = 0;
      } else {
        status = 1;
      }
      var timestamp = new Date().getTime()
      var param = { shop_id: loginInfo.shop_id, status: status, sou: _this.search.data.inputValue, timestamp: timestamp }
      var str = Sign.sign(param)
      wx.request({
        url: app.globalData.request + '/outapi/store-goods/dlist',
        method: "POST",
        data: {
          shop_id: loginInfo.shop_id,
          status: status,
          sou: _this.search.data.inputValue,
          timestamp: timestamp,
          sign: str
        },
        success: function (res) {
          console.log(res)
          if (res.data.code == 0) {
            var resinfo = res.data.res.goods_list;
            for (var i in resinfo) {
              resinfo[i].flag = false;
            }
            _this.setData({
              list: resinfo,
              seaPop: false,
              search_value: _this.search.data.inputValue
            })
          } else {
            wx.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 3000
            })
          }
        }
      })
    }
  },
  //确定
  sure () {
    var checklist = [];
    var list = this.data.list;
    for (var i in list) {
      if (list[i].flag) {
        checklist.push(list[i])
      }
    }
    if(wx.getStorageSync("checklist")){
      var oldlist = wx.getStorageSync("checklist");//旧
      // var checklist = _this.data.checklist;//新
      var aimlist = [];
      for (var index in oldlist) {
        aimlist.push(oldlist[index].goods_name)
      }
      for (var i in checklist) {
        let index = aimlist.indexOf(checklist[i].goods_name)
        if (index == -1) {//名字不一样
          oldlist.push(checklist[i])
        } 
        // else {//名字一样
        //   if (Number(checklist[i].buying_price) == Number(oldlist[index].buying_price)) {
        //     oldlist[index].buying_num = Number(Number(oldlist[index].buying_num) + Number(checklist[i].buying_num));
        //   } else {
        //     oldlist[index] = checklist[i];
        //   }
        // }
      }
      wx.setStorageSync("checklist", oldlist);
    }else{
      wx.setStorageSync("checklist", checklist);
    }
    wx.navigateBack({
      delta: 1
    })
  },
  //重置
  reset () {
    var _this = this;
    var list = this.data.list;
    for(var i in list){
      if(list[i].flag){
        var aim = "list["+i+"].flag";
        _this.setData({
          [aim]:false
        })
      }
    }
  }
})