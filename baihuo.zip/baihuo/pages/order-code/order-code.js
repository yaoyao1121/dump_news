var QR = require("../../utils/qrcode.js")
const app = getApp()
const Sign = require("../../utils/util.js")

Page({
  data: {
    //订单信息
    orderInfo: {},
    codeImg: "",
    order_id:"",
    userInfo:{}
  },
  onLoad(options) {
    this.setData({
      order_id: options.orderId
    })

  },
  onShow () {
    //生成二维码
    var order_id = this.data.order_id;
    console.log(order_id)
    var size = this.setCanvasSize()
    this.createQrCode(order_id, "mycanvas", size.w, size.h)
    this.setData({
      userInfo: wx.getStorageSync("loginInfo")
    });
    this.getOrderDetail();
  },
  //获取订单详情
  getOrderDetail() {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var order_id = this.data.order_id;
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, order_id: order_id, timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-orders/info',
      method: "POST",
      data: {
        shop_id: loginInfo.shop_id,
        order_id: order_id,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        console.log(res);
        if (res.data.code == 0) {
          // _this.setData({
          //   orderInfo: res.data.res
          // })
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  },
  setCanvasSize: function () {
    var size = {};
    try {
      var res = wx.getSystemInfoSync();
      var scale = 750 / 330;//不同屏幕下canvas的适配比例；设计稿是750宽
      var width = res.windowWidth / scale;
      var height = width;//canvas画布为正方形
      size.w = width;
      size.h = height;
      console.log(width, height)
    } catch (e) {
      // Do something when catch error
    }
    return size;
  },
  createQrCode: function (url, canvasId, cavW, cavH) {
    //调用插件中的draw方法，绘制二维码图片
    QR.qrApi.draw(url, canvasId, cavW, cavH);
  }
})