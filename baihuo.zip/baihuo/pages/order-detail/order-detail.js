var QR = require("../../utils/qrcode.js")
const app = getApp()
const Sign = require("../../utils/util.js")
Page({
  data: {
    //订单信息
    orderInfo:{},
    codeImg:"",
    //确认取货弹框
    popGet:false
  },
  onShow () {
    //生成二维码
    var order_id = wx.getStorageSync("order_id");
    var size = this.setCanvasSize()
    this.createQrCode(order_id, "mycanvas", size.w, size.h)
    this.setData({
      userInfo: wx.getStorageSync("loginInfo")
    });
    this.getOrderDetail();
  },
  //获取订单详情
  getOrderDetail () {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var order_id = wx.getStorageSync("order_id");
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, order_id: order_id, timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-orders/info',
      method: "POST",
      data: {
        shop_id: loginInfo.shop_id,
        order_id: order_id,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        console.log(res);
        if (res.data.code == 0) {
          _this.setData({
            orderInfo:res.data.res
          })
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  },
  setCanvasSize: function () {
    var size = {};
    try {
      var res = wx.getSystemInfoSync();
      var scale = 750 / 170;//不同屏幕下canvas的适配比例；设计稿是750宽
      var width = res.windowWidth / scale;
      var height = width;//canvas画布为正方形
      size.w = width;
      size.h = height;
      console.log(width,height)
    } catch (e) {
      // Do something when catch error
    }
    return size;
  },
  createQrCode: function (url, canvasId, cavW, cavH) {
    //调用插件中的draw方法，绘制二维码图片
    QR.qrApi.draw(url, canvasId, cavW, cavH);
  },
  //二维码预览
  previewImg() {
    var _this = this;
    wx.canvasToTempFilePath({
      fileType: "jpg",
      canvasId: 'mycanvas',
      success: function (res) {
        console.log(res.tempFilePath,"路径")
        _this.setData({
          img: res.tempFilePath
        })
        wx.previewImage({
          urls: [res.tempFilePath],
        })
      }
    })
  },
  //确认收货弹框
  sure (e) {
    var _this = this;
    if (e.currentTarget.dataset.flag == 4){
      _this.setData({
        popGet:true
      })
    }
  },
  //批次 弹框隐藏
  cancelCharge() {
    this.setData({
      popGet: false
    })
  },
  //确认取货
  sureCharge() {
    var _this = this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var order_id = wx.getStorageSync("order_id");
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, account: loginInfo.account, identity: loginInfo.identity, order_id: order_id,timestamp: timestamp}
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-orders/pickup',
      method: 'POST',
      data: {
        shop_id: loginInfo.shop_id, 
        account: loginInfo.account, 
        identity: loginInfo.identity, 
        order_id: order_id,
        timestamp: timestamp,
        sign: str
      },
      success(res) {
        console.log(res)
        if (res.data.code == 0) {
          _this.setData({
            popGet:false
          })
          wx.showToast({
            title: "收货成功",
            icon: 'none',
            duration: 3000
          });
          _this.getOrderDetail();
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  }
})