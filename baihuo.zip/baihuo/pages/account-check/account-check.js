//获取应用实例
const app = getApp()
const Sign = require("../../utils/util.js")
Page({
  data: {
    //日期
    selectTime: Sign.prevDay(new Date(),1),
    oselectTime: Sign.prevDay(new Date(), 2),
    optional: "../../images/zuolv.png",
    noOptional: "../../images/youhui.png",
    today: Sign.prevDay(new Date(), 1),
    accountInfo:{}
  },
  onShow() {
    this.getLists();
  },
  //进入订单列表
  toOrderList (e) {
    wx.navigateTo({
      url: '/pages/order-list/order-list?vtime=' + e.currentTarget.dataset.vtime
    })
  },
  getLists(){
    var _this=this;
    var loginInfo = wx.getStorageSync("loginInfo");
    var time = this.data.selectTime;
    var timestamp = new Date().getTime()
    var param = { shop_id: loginInfo.shop_id, account: loginInfo.account, identity: loginInfo.identity, time:time,timestamp: timestamp }
    var str = Sign.sign(param)
    wx.request({
      url: app.globalData.request + '/outapi/store-orders/check',
      method: "POST",
      data: {
        shop_id: loginInfo.shop_id, 
        account: loginInfo.account,
        identity: loginInfo.identity, 
        time: time,
        timestamp: timestamp,
        sign: str
      },
      success: function (res) {
        if (res.data.code == 0) {
          _this.setData({
            accountInfo:res.data.res
          })
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            duration: 3000
          })
        }
      }
    })
  },
  startTimeChange(e){
    var selectTime = e.detail.value;
    var oselectTime = Sign.prevDay(selectTime,2);
    this.setData({
      selectTime: selectTime,
      oselectTime: oselectTime
    })
    if (selectTime != this.data.today) {
      this.setData({
        noOptional: "../../images/youlv.png"
      })
    }else{
      this.setData({
        noOptional: "../../images/youhui.png"
      })
    }
    this.getLists();
  },
  prev(){
    var selectTime = Sign.prevDay(this.data.selectTime, 1);
    var oselectTime = Sign.prevDay(this.data.selectTime, 3);
    this.setData({
      selectTime: selectTime,
      oselectTime: oselectTime
    })
    if (selectTime != this.data.today) {
      this.setData({
        noOptional: "../../images/youlv.png"
      })
    } else {
      this.setData({
        noOptional: "../../images/youhui.png"
      })
    }
    this.getLists();
  },
  next() {
    if (this.data.selectTime == this.data.today){
      return;
    }
    var selectTime = Sign.nextDay(this.data.selectTime, 1);
    var oselectTime = Sign.prevDay(selectTime, 2);   
    this.setData({
      selectTime: selectTime,
      oselectTime: oselectTime
    })
    if (selectTime != this.data.today) {
      this.setData({
        noOptional: "../../images/youlv.png"
      })
    } else {
      this.setData({
        noOptional: "../../images/youhui.png"
      })
    }
    this.getLists();
  }
})