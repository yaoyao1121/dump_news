//app.js
App({
  onLaunch: function () {
    
  },
  globalData: {
    request: 'https://ptest1.pilifu.com'
  }
})