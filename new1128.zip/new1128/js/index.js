$(document).ready(function(){
		 /* 让ie7,8,9支持input的placeholder属性*/
	     $('input, textarea').placeholder();
});